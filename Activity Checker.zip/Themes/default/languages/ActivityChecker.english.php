<?php
/**
* @package RPG Date and Calendar Mod
*
* @author Cody Williams
* @copyright 2015
* @version 1.2
* @license BSD 3-clause
*/
// First of all, we make sure we are accessing the source file via SMF so that people can not directly access the file. 
if (!defined('SMF'))
  die('Hack Attempt...');
  
$txt['activity_checker_label'] = 'Activity Checker';
$txt['activity_checker_desc'] = 'Check when the last post of members were and change their membergroup.';
$txt['activity_checker_general'] = 'Activity Checker Settings';
$txt['activity_checker_inactive_list'] = 'Newly Inactive Member List';
$txt['activity_checker_active_list'] = 'Newly Active Member List';
$txt['activity_checker_no_posts_list'] = 'Never Posted Member List';
$txt['activity_checker_general_desc'] = 'Membergroup and Category Settings.';
$txt['activity_checker_inactive_desc'] = 'A list of members who are currently inactive.';
$txt['activity_checker_active_desc'] = 'A list of members in the inactive membergroup who are now active again.';
$txt['activity_checker_no_posts_desc'] = 'A list of members who have never made a post in the specified categories.';


$txt['activity_checker_list_title'] = 'Member Activity List';
$txt['activity_checker_no_inactive'] = 'There are no currently inactive members';
$txt['activity_checker_member_name_title'] = 'Member Name';
$txt['last-post'] = 'Last Post';
$txt['activity_checker_settings'] = 'Activity Checker Settings';

$txt['activity_checker_membergroup_settings_title'] = 'Membergroups To Exclude From Activity Check';
$txt['activity_checker_membergroup_col'] = 'Membergroup';
$txt['activity_checker_description_col'] = 'Description';
$txt['activity_checker_notGroup_col'] = 'Do Not Include in Check';


$txt['activity_checker_category_settings_title'] = 'Categories to Check Activity In';
$txt['activity_checker_category_col'] = 'Category';
$txt['activity_checker_catChecked_col'] = 'Check for Activity';
?>