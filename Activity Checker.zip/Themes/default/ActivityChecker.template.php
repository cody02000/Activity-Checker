<?php
/**
* @package RPG Date and Calendar Mod
*
* @author Cody Williams
* @copyright 2015
* @version 1.2
* @license BSD 3-clause
*/

// Editing or adding holidays.




function template_general_settings()
{	

	//	Show the list.
	template_show_list('activity_checker_membergroup_selector');
	
	template_show_list('activity_checker_category_selector');

}

function template_inactive()
{
	template_show_list();
}

function template_active()
{
	template_show_list();
}

function template_no_posts()
{
	template_show_list();
}