<?php
/**
* @package Activity Checker
*
* @author Cody Williams
* @copyright 2015
* @version 1.2
* @license BSD 3-clause
*/

// First of all, we make sure we are accessing the source file via SMF so that people can not directly access the file. 
if (!defined('SMF'))
  die('Hack Attempt...');


/**
 *  Sets up admin areas.
 *  
 *  Called by integrate_admin_areas hook.
 *  
 *  @param array $admin_areas
 */
function activityChecker_adminMenu(&$admin_areas)
{
  global $txt, $scripturl;
  loadLanguage('ActivityChecker');
  $admin_areas['config']['areas']['activity_checker']=array(
    'label' => $txt['activity_checker_label'],
    'file' => 'ActivityChecker.php',
    'function' => 'activityChecker_adminMain',
    'custom_url' => $scripturl . '?action=admin;area=activity_checker',
    'icon' => 'calendar.gif',
	'subsections' => array(
        'settings' => array($txt['activity_checker_general'], 'admin_forum',),
        'inactive_list' => array($txt['activity_checker_inactive_list'], 'admin_forum',),
		'active_list' => array($txt['activity_checker_active_list'], 'admin_forum',),
		'no_posts_list' => array($txt['activity_checker_no_posts_list'], 'admin_forum',),
	)
	);
}

// The main controlling function doesn't have much to do... yet.
function activityChecker_adminMain()
{
	global $context, $txt, $scripturl, $modSettings;
	loadTemplate('ActivityChecker');
	loadLanguage('ActivityChecker');

	// Default text.
	$context['explain_text'] = $txt['activity_checker_desc'];

	// Little short on the ground of functions here... but things can and maybe will change...
	$subActions = array(
		'inactive_list' => 'activityChecker_inactiveList',
		'active_list' => 'activityChecker_activeList',
		'no_posts_list' => 'activityChecker_noPostsList',
		'settings' => 'activityChecker_settings',
	);
	
	

	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'settings';

	
	  // Set up the two tabs here...
	$context[$context['admin_menu_name']]['tab_data'] = array(
	'title' => $txt['rpg_age'],
	'help' => 'rpg_age_help',
	'description' => $txt['rpg_age_desc'],
	'tabs' => array(
		'settings' => array(
			'description' => $txt['activity_checker_general_desc'],
		),
		'inactive_list' => array(
			'description' => $txt['activity_checker_inactive_desc'],
		),
		'active_list' => array(
			'description' => $txt['activity_checker_active_desc'],
		),
		'no_posts_list' => array(
			'description' => $txt['activity_checker_no_posts_desc'],
		),
	),
	);

	$subActions[$_REQUEST['sa']]();
}

// The function that handles adding, and deleting holiday data
function activityChecker_activelist($return_config = false)
{
	global $sourcedir, $txt, $scripturl, $context, $settings, $sc, $modSettings, $smcFunc;
	require_once($sourcedir . '/ManageServer.php');
	// Submitting something...
	if (isset($_REQUEST['mark_inactive']))
	{
		checkSession();

	}
	else {
		$listOptions = array(
			'id' => 'activity_list',
			'title' => $txt['activity_checker_list_title'],
			'items_per_page' => 10,
			'base_href' => $scripturl . '?action=admin;area=activity_checker',
			'default_sort_col' => 'last_post',
			'get_items' => array(
				'function' => 'list_ActivityChecker',
			),
			'get_count' => array(
				'function' => 'activityCheckerListGetNumEvents',
			),
			'no_items_label' => $txt['activity_checker_no_inactive'],
			'columns' => array(
				'name' => array(
					'header' => array(
						'value' => $txt['activity_checker_member_name_title'],
					),
					'data' => array(
						'db' => 'member_link',
					),
					'sort' => array(
						'default' => 'real_name',
						'reverse' => 'real_name DESC',
					)
				),
				'last_post' => array(
					'header' => array(
						'value' => $txt['last-post'],
					),
					'data' => array(
						'db' => 'last_post_link',
					),
					'sort' => array(
						'default' => 'msg.poster_time',
						'reverse' => 'msg.poster_time DESC',
					),
				),
				'check' => array(
					'header' => array(
						'value' => '<input type="checkbox" onclick="invertAll(this, this.form);" class="input_check" />',
					),
					'data' => array(
						'sprintf' => array(
							'format' => '<input type="checkbox" name="member[%1$d]" class="input_check" />',
							'params' => array(
								'id_member' => false,
							),
						),
						'style' => 'text-align: center',
					),
				),
			),
			'form' => array(
				'href' => $scripturl . '?action=admin;area=activity_checker;sa=list',
			),
			'additional_rows' => array(
				array(
					'position' => 'below_table_data',
					'value' => '
						<a href="' . $scripturl . '?action=admin;area=rpg_cal;sa=edit_event" style="margin: 0 1em">[' . $txt['rpg_cal_event_add'] . ']</a>
						<input type="submit" name="delete" value="' . $txt['quickmod_delete_selected'] . '" class="button_submit" />',
					'style' => 'text-align: right;',
				),
			),
		);

		require_once($sourcedir . '/Subs-List.php');
		createList($listOptions);
		
		if ($return_config)
			return $config_vars;
		
		if(isset($_GET['update'])) {
			//	Make sure that an admin is doing the updating.
			checkSession();	
			//	Save the config vars.
			writeLog();
			saveDBSettings($config_vars);
			redirectexit("action=admin;area=activity_checker;sa=list;");
			}
		
		$context['page_title'] = $txt['activity_checker_label'];
		//	Set up the variables needed by the template.
		$context['settings_title'] = $txt['activity_checker_settings'];	
		$context['default_list'] = 'activity_list';
		$context['post_url'] = $scripturl . '?action=admin;area=activity_checker;sa=list;update';
		loadTemplate('ActivityChecker');
		
		$context['sub_template'] = 'inactive';
	}
}

function activityCheckerListGetNumEvents()
{
	global $smcFunc, $txt, $scripturl, $modSettings;
	
	$memberGroups=array_map('intval',explode(',',$modSettings['activity_checker_inactive_membergroups']));
	
	$result = $smcFunc['db_query']('', '
		SELECT id_member
			FROM {db_prefix}members
			WHERE id_group NOT IN ({array_int:membergroups})',
		array(
			'membergroups' => $memberGroups,
		)
	);
	$members = array();
	while($row = $smcFunc['db_fetch_assoc']($result))
		$members[] = $row['id_member'];
	// Free the db resource.
	$smcFunc['db_free_result']($result);
	
	// Query to make a list of the 'last post' for each member.
	$result = $smcFunc['db_query']('', '
		SELECT MAX(id_msg) AS id_msg
		FROM {db_prefix}messages
		WHERE id_member IN ({array_int:members})
		GROUP BY id_member',
		array(
			'members' => $members,
		)
	);
	
	// Make a list of the 'lastest posts' for each member
	$last_posts = array();
	while($row = $smcFunc['db_fetch_assoc']($result))
		$last_posts[] = $row['id_msg'];
	
	// Free the db resource.
	$smcFunc['db_free_result']($result);
	
	$request = $smcFunc['db_query']('', '
		SELECT mem.id_member, mem.real_name, mem.usertitle, mem.date_registered,mem.id_group,
			msg.id_member, msg.id_msg, msg.id_topic, msg.poster_time
		FROM {db_prefix}messages AS msg
			INNER JOIN {db_prefix}members AS mem ON (mem.id_member=msg.id_member)
		WHERE msg.id_msg IN ({array_int:last_posts})
			AND mem.id_group NOT IN ({array_int:member_groups})
			AND msg.poster_time >= {int:inactive_weeks}',
		array(
			'member_groups' => $memberGroups,
			'last_posts' => $last_posts,
			'inactive_weeks' => time()-(60*60*24*(7*6)),
		)
	);
	$activity_checker = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$activity_checker[] = array(
			'id_member' => $row['id_member'],
			'member_link' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '">' . $row['real_name'] . '</a>',
			'last_post_link' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.msg' . $row['id_msg'] . '#msg' . $row['id_msg'] . '">' . $row['poster_time'] . '</a>',
			'last_post_time' => $row['poster_time'],
		);
	}
	$smcFunc['db_free_result']($request);
  
  
  
 $num_items = count($activity_checker);
 var_dump($num_items);

  return $num_items;
}

function list_ActivityChecker($start, $items_per_page, $sort)
{
	global $smcFunc, $txt, $scripturl, $modSettings;
	
	$memberGroups=array_map('intval',explode(',',$modSettings['activity_checker_inactive_membergroups']));
	var_dump($memberGroups);
	
	$result = $smcFunc['db_query']('', '
		SELECT id_member
			FROM {db_prefix}members
			WHERE id_group NOT IN ({array_int:membergroups})
			ORDER BY id_member',
		array(
			'membergroups' => $memberGroups,
		)
	);
	$members = array();
	while($row = $smcFunc['db_fetch_assoc']($result))
		$members[] = $row['id_member'];
	// Free the db resource.
	$smcFunc['db_free_result']($result);
	
	// Query to make a list of the 'last post' for each member.
	$result = $smcFunc['db_query']('', '
		SELECT MAX(id_msg) AS id_msg
		FROM {db_prefix}messages
		WHERE id_member IN ({array_int:members})
		GROUP BY id_member
		ORDER BY id_member',
		array(
			'members' => $members,
		)
	);
	
	// Make a list of the 'lastest posts' for each member
	$last_posts = array();
	while($row = $smcFunc['db_fetch_assoc']($result))
		$last_posts[] = $row['id_msg'];
	
	// Free the db resource.
	$smcFunc['db_free_result']($result);
	
	$request = $smcFunc['db_query']('', '
		SELECT mem.id_member, mem.real_name, mem.usertitle, mem.date_registered,mem.id_group,
			msg.id_member, msg.id_msg, msg.id_topic, msg.poster_time
		FROM {db_prefix}messages AS msg
			INNER JOIN {db_prefix}members AS mem ON (mem.id_member=msg.id_member)
		WHERE msg.id_msg IN ({array_int:last_posts})
			AND mem.id_group NOT IN ({array_int:member_groups})
			AND msg.poster_time >= {int:inactive_weeks}
			AND msg
		ORDER BY {raw:sort}
		LIMIT ' . $start . ', ' . $items_per_page,		
		array(
			'member_groups' => $memberGroups,
			'last_posts' => $last_posts,
			'sort' => $sort,
			'inactive_weeks' => time()-(60*60*24*(7*6)),
		)
	);
	$activity_checker = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$activity_checker[] = array(
			'id_member' => $row['id_member'],
			'member_link' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '">' . $row['real_name'] . '</a>',
			'last_post_link' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.msg' . $row['id_msg'] . '#msg' . $row['id_msg'] . '">' . $row['poster_time'] . '</a>',
			'last_post_time' => $row['poster_time'],
		);
	}
	$smcFunc['db_free_result']($request);
	foreach ($activity_checker as $key => $val) {
		echo $key .', '.$val['id_member'].', '.$val['member_link'] .'<br />';
	}
	return $activity_checker;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function activityChecker_settings()
{
	global $txt, $scripturl, $context, $settings, $sc, $smcFunc;
	global $modSettings, $sourcedir;

	$context['page_title'] = $txt['activity_checker_settings'];
	$context['sub_template'] = 'general_settings';
		echo '<pre>';
		var_dump($_POST);
		echo '</pre>';
	// Are we saving any standard field changes?
	if (isset($_POST['save']))
	{
		checkSession();
		
		if (!empty($_POST['notGroup']))
		{
			$changes['activityChecker_NotMembergroups'] = implode(',', $_POST['notGroup']);
		}
		
		if (!empty($_POST['catChecked']))
		{
			$changes['activityChecker_categories'] = implode(',', $_POST['catChecked']);
		}
		
		if (!empty($changes))
			updateSettings($changes);
	}

	require_once($sourcedir . '/Subs-List.php');

	$listOptions = array(
		'id' => 'activity_checker_membergroup_selector',
		'title' => $txt['activity_checker_membergroup_settings_title'],
		'base_href' => $scripturl . '?action=admin;area=activity_checker;sa=settings',
		'get_items' => array(
			'function' => 'list_getActivityCheckerSettings',
			'params' => array(
				true,
			),
		),
		'columns' => array(
			'membergroup' => array(
				'header' => array(
					'value' => $txt['activity_checker_membergroup_col'],
					'style' => 'text-align: left;',
				),
				'data' => array(
					'db' => 'membergroup_link',
					'style' => 'width: 60%;',
				),
			),
			'group_description' => array(
				'header' => array(
					'value' => $txt['activity_checker_description_col'],
					'style' => 'text-align: left;',
				),
				'data' => array(
					'db' => 'description',
					'style' => 'width: 20%;',
				),
			),
			'notGroup' => array(
				'header' => array(
					'value' => $txt['activity_checker_notGroup_col'],
				),
				'data' => array(
					'function' => create_function('$rowData', '
						$isChecked = $rowData[\'notGroup\'] ? \' checked="checked"\' : \'\';
						return sprintf(\'<input type="checkbox" name="notGroup[]" id="notGroup_%1$s" value="%1$s" class="input_check"%2$s />\', $rowData[\'id_group\'], $isChecked);
					'),
					'style' => 'width: 20%; text-align: center;',
				),
			),
		),
		'form' => array(
			'href' => $scripturl . '?action=admin;area=activity_checker;sa=settings',
			'name' => 'NotMembergroup',
		),
		'additional_rows' => array(
			array(
				'position' => 'below_table_data',
				'value' => '<input type="submit" name="save" value="' . $txt['save'] . '" class="button_submit" />',
				'style' => 'text-align: right;',
			),
		),
	);
	createList($listOptions);

	$listOptions = array(
		'id' => 'activity_checker_category_selector',
		'title' => $txt['activity_checker_category_settings_title'],
		'base_href' => $scripturl . '?action=admin;area=activity_checker;sa=settings',
		'get_items' => array(
			'function' => 'list_getActivityCheckerSettings',
			'params' => array(
				false,
			),
		),
		'columns' => array(
			'category' => array(
				'header' => array(
					'value' => $txt['activity_checker_category_col'],
					'style' => 'text-align: left;',
				),
				'data' => array(
					'db' => 'category_link',
					'style' => 'width: 80%;',
				),
			),
			'catChecked' => array(
				'header' => array(
					'value' => $txt['activity_checker_catChecked_col'],
				),
				'data' => array(
					'function' => create_function('$rowData', '
						$isChecked = $rowData[\'catChecked\'] ? \' checked="checked"\' :\'\';
						return sprintf(\'<input type="checkbox" name="catChecked[]" id="catChecked_%1$s" value="%1$s" class="input_check"%2$s />\', $rowData[\'id_cat\'], $isChecked);
					'),
					'style' => 'width: 20%; text-align: center;',
				),
			),
		),
		'form' => array(
			'href' => $scripturl . '?action=admin;area=activity_checker;sa=settings',
			'name' => 'NotMembergroup',
		),
		'additional_rows' => array(
			array(
				'position' => 'below_table_data',
				'value' => '<input type="submit" name="save" value="' . $txt['save'] . '" class="button_submit" />',
				'style' => 'text-align: right;',
			),
		),
	);
	createList($listOptions);
	
}

function list_getActivityCheckerSettings($start, $items_per_page, $sort, $groups)
{
	global $txt, $modSettings, $smcFunc, $scripturl;

	$list = array();

	if ($groups) {
		// Load all the fields.
		$request = $smcFunc['db_query']('', '
			SELECT id_group, group_name, description
			FROM {db_prefix}membergroups'
		);
		$notInGroups = isset($modSettings['activity_checker_inactive_membergroups']) ? explode(',', $modSettings['activity_checker_inactive_membergroups']) : array();
		while ($row = $smcFunc['db_fetch_assoc']($request)) {
			$list[] = array(
				'membergroup_link' => '<a href="' . $scripturl . '?action=admin;area=membergroups;sa=members;group=' . $row['id_group'] . '">' . $row['group_name'] . '</a>',
				'id_group' => $row['id_group'],
				'description' => $row['description'],
				'notGroup' => in_array($row['id_group'], $notInGroups),
			);
		}
		$smcFunc['db_free_result']($request);
	}

	else {
		$request = $smcFunc['db_query']('', '
			SELECT id_cat, name
			FROM {db_prefix}categories'
		);
		$checkedCat = isset($modSettings['activity_checker_cats']) ? explode(',', $modSettings['activity_checker_cats']) : array();
		while ($row = $smcFunc['db_fetch_assoc']($request)) {
			$list[] = array(
				'category_link' => '<a href="' . $scripturl . '?action=admin;area=manageboards;sa=cat;cat=' . $row['id_cat'] . '">' . $row['name'] . '</a>',
				'id_cat' => $row['id_cat'],
				'catChecked' => in_array($row['id_cat'], $checkedCat),
			);
		}
		$smcFunc['db_free_result']($request);
	}
	
	return $list;
}